/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tiketbioskop;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author ACER
 */
public class ControllerEditMakanan {
    VEditMakanan VE;
    ModelBioskop MB;
    String[] makanan;

    public ControllerEditMakanan(VEditMakanan VE, ModelBioskop MB, String[] makanan) {
        this.VE = VE;
        this.MB = MB;
        this.makanan = makanan;
        setForm();
        VE.BTNEdit.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                MB.editMakanan(Integer.parseInt(makanan[0]), VE.getNamaPaket(), VE.getHarga());
//                ControllerDaftarMakanan
            }
            
        });
    }
    void setForm(){
        VE.TFNamaPaket.setText(makanan[1]);
        VE.TFHarga.setText(makanan[2]);
    }
}
