/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tiketbioskop;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.DefaultComboBoxModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 *
 * @author ACER
 */
public class ControllerEditFilm {

    VEditFilm VE;
    ModelBioskop MB;
    String datafilm[][];
    String studio;
    int price = 0;

    public ControllerEditFilm(VEditFilm VE, ModelBioskop MB, String id, String nama, String tanggal, String judul, String jam, String harga) {
        this.VE = VE;
        this.MB = MB;
        ShowFilm();
        if (judul.equals("The Legend Super Dede")) {
            VE.cbfilm.setSelectedIndex(0);
        } else if (judul.equals("BoboiBoy Pengangguran")) {
            VE.cbfilm.setSelectedIndex(1);
        } else if (judul.equals("Si Madun vs Alex Bizer")) {
            VE.cbfilm.setSelectedIndex(2);
        } else if (judul.equals("Khanzab")) {
            VE.cbfilm.setSelectedIndex(3);
        } else if (judul.equals("Interstellar on Planet Bekasi")) {
            VE.cbfilm.setSelectedIndex(4);
        }
        
        VE.sjumlah.setValue(0);
        
        VE.SR.addItemListener(new ItemListener (){
            @Override
            public void itemStateChanged(ItemEvent e) {
                if(e.getStateChange()==ItemEvent.SELECTED ){
                    studio="Reguler";
                }
            } 
        });
        VE.SP.addItemListener(new ItemListener (){
            @Override
            public void itemStateChanged(ItemEvent e) {
                if(e.getStateChange()==ItemEvent.SELECTED ){
                    studio="Premiere";
                }
            } 
        });
        VE.SD.addItemListener(new ItemListener (){
            @Override
            public void itemStateChanged(ItemEvent e) {
                if(e.getStateChange()==ItemEvent.SELECTED ){
                    studio="Dolby Atmos";
                }
            } 
        });
        VE.SI.addItemListener(new ItemListener (){
            @Override
            public void itemStateChanged(ItemEvent e) {
                if(e.getStateChange()==ItemEvent.SELECTED ){
                    studio="Imax";
                }
            } 
        });
        VE.sjumlah.addChangeListener(new ChangeListener(){
            @Override
            public void stateChanged(ChangeEvent e) {
                int jumlah=(int) VE.sjumlah.getValue();
                price = jumlah*35000;
                VE.lharga.setText(Integer.toString(price));
            }
        });
        
        VE.SFilm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                String tanggal = VE.cbtanggal.getSelectedItem().toString();
                String judul = VE.cbfilm.getSelectedItem().toString();
                String jam = VE.cbwaktu.getSelectedItem().toString();
                String harga = VE.lharga.getText().toString();
                
                MB.hasilTiketFilm(studio, tanggal, judul, jam, harga, id);
                VE.dispose();
                new ControllerTransaksiFilm(new VTransaksiFilm(), new ModelBioskop());
            }
        });
    }
    
    
    void ShowFilm(){
        datafilm=MB.readDataFilm();
        String[] film=new String[MB.jumlahFilm()];
        for(int i=0;i<MB.jumlahFilm();i++){
            film[i]=datafilm[i][1];
        }
        VE.cbfilm.setModel(new DefaultComboBoxModel(film));
        VE.cbfilm.setSelectedIndex(-1);
    }

}
