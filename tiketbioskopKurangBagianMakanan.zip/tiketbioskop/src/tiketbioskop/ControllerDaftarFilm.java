/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tiketbioskop;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.table.DefaultTableModel;

public class ControllerDaftarFilm {
    VDaftarFilm VD;
    ModelBioskop MB;
    String[][] datatabel;
    public ControllerDaftarFilm( VDaftarFilm VD, ModelBioskop MB) {
        this.VD = VD;
        this.MB = MB;
        ShowDataFilm();
        VD.btnMenu.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                VMainMenu MM =new VMainMenu();
                ControllerMenu CM = new ControllerMenu (MM,MB);
                MM.setVisible(true);
                VD.dispose();
            } 
        });
        VD.btnTiket.addActionListener(new ActionListener (){
            @Override
            public void actionPerformed(ActionEvent e) {
               VTiketFilm VT =new VTiketFilm();
               ControllerTiketFilm CF = new ControllerTiketFilm (VT,MB);
               VT.setVisible(true);
               VD.dispose();
            }
        });
        VD.tabelFilm.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                int row = VD.tabelFilm.getSelectedRow();
                String id = datatabel[row][0];
                String judul=datatabel[row][1];
                int input = JOptionPane.showConfirmDialog(null,
                        "Hapus film '"+judul+"'?",
                        "Option",
                        JOptionPane.YES_NO_OPTION); // yes =0, no=1
                
                if(input==0){
                    MB.hapusFilm(Integer.parseInt(id));
                    ShowDataFilm();
                }
                else{
                    int input1 = JOptionPane.showConfirmDialog(null,
                        "Edit film '"+ judul + "'?",
                        "Option",
                        JOptionPane.YES_NO_OPTION); // yes =0, n0=1
                
                    if(input1==0){
                        VEditFilm VE=new VEditFilm();
//                        ControllerEditFilm CE=new ControllerEditFilm(VE,MB,datatabel[row]);
                        VE.setVisible(true);
                        VD.dispose();
                    }
                }
            }            
        });
        
    }
    void ShowDataFilm(){
        datatabel=MB.readDataFilm();
        String[] namakolom={"id film","Nama film","genre","usia"};
        VD.tabelFilm.setModel((new JTable(datatabel,namakolom)).getModel());
    }
}
