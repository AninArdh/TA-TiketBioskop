/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tiketbioskop;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.table.DefaultTableModel;

public class ControllerDaftarMakanan {
    VDaftarMakanan DM;
    ModelBioskop MB;
    String[][] datatabel;
    public ControllerDaftarMakanan(VDaftarMakanan DM, ModelBioskop MB) {
        this.DM=DM;
        this.MB=MB;
        ShowDataMakanan();
        DM.btnMenu.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                VMainMenu MM =new VMainMenu();
                ControllerMenu CM = new ControllerMenu (MM,MB);
                MM.setVisible(true);
                DM.dispose();
            } 
        });
        DM.btnTiket.addActionListener(new ActionListener (){
            @Override
            public void actionPerformed(ActionEvent e) {
               VTiketMakanan VM =new VTiketMakanan();
               ControllerTiketMakanan CM = new ControllerTiketMakanan (VM,MB);
               VM.setVisible(true);
               DM.dispose();
            }
        });
        DM.tabelMakanan.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                int row = DM.tabelMakanan.getSelectedRow();
                String id = datatabel[row][0];
                String paket=datatabel[row][1];
                int input = JOptionPane.showConfirmDialog(null,
                        "Hapus makanan '"+paket+"'?",
                        "Option",
                        JOptionPane.YES_NO_OPTION); // yes =0, no=1
                
                if(input==0){
                    MB.hapusMakanan(Integer.parseInt(id)); 
                    ShowDataMakanan();
                }
                else{
                    int input1 = JOptionPane.showConfirmDialog(null,
                        "Edit makanan '"+ paket + "'?",
                        "Option",
                        JOptionPane.YES_NO_OPTION); // yes =0, n0=1
                
                    if(input1==0){
                        VEditMakanan VE=new VEditMakanan();
                        ControllerEditMakanan CE=new ControllerEditMakanan(VE,MB,datatabel[row]);
                        VE.setVisible(true);
                        DM.dispose();
                    }
                }
            }            
        });
        
    }
    void ShowDataMakanan(){
        datatabel=MB.readDataMakanan();
        String[] namakolom={"ID Makanan","Nama Makanan","Harga"};
        DM.tabelMakanan.setModel((new JTable(datatabel,namakolom)).getModel());
    }
}
