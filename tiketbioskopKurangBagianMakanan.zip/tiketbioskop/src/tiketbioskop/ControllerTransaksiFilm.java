/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tiketbioskop;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.table.DefaultTableModel;

public class ControllerTransaksiFilm {
    VTransaksiFilm VB;
    ModelBioskop MB;
    String id, nama, tanggal, judul, jam, harga;
    String dataT[][];
    public ControllerTransaksiFilm(VTransaksiFilm VB,ModelBioskop MB) {
        this.VB=VB;
        this.MB=MB;
        String data[][] = MB.readDataTransaksiFilm();
        VB.TFilm.setModel(new DefaultTableModel(data, new String[]{
            "id_pemesanan","nama_studio","tanggal","judul_film","jam_mulai","harga"
        }));
         VB.btnMenu.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                VMainMenu MM =new VMainMenu();
                ControllerMenu CM = new ControllerMenu (MM,MB);
                MM.setVisible(true);
                VB.dispose();
            } 
        });
         VB.TFilm.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); 
                int row = VB.TFilm.getSelectedRow();
                id = VB.TFilm.getValueAt(row, 0).toString();
                nama = VB.TFilm.getValueAt(row, 1).toString();    
                tanggal = VB.TFilm.getValueAt(row, 2).toString();
                judul = VB.TFilm.getValueAt(row, 3).toString();
                jam = VB.TFilm.getValueAt(row, 4).toString();
                harga = VB.TFilm.getValueAt(row, 5).toString();
            }
             
         });
         VB.EFilm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VB.dispose();
                new ControllerEditFilm(new VEditFilm(), new ModelBioskop(), id, nama, tanggal, judul, jam, harga);
            }
         });
         VB.btndelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                MB.deleteTiket(id);
                dataT = MB.readDataTransaksiFilm();
                VB.TFilm.setModel(new DefaultTableModel(dataT, new String [] {
                    "id_pemesan","nama_studio","tanggal","judul_film","jam,_mulai","harga"
                }));
            }
         });
    }
    
}
